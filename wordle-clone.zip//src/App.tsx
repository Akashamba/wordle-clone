import { ReactElement, useEffect, useState } from "react";
import { Line } from "./components/grid-components";
import "./styles.css";

const API_URL = "https://api.frontendexpert.io/api/fe/wordle-words";

export default function App() {
  const [answer, setAnswer] = useState<string>("");
  const [currentGuess, setCurrentGuess] = useState<string>("");
  const [turnNumber, setTurnNumber] = useState<number>(0);
  const [guesses, setGuesses] = useState<string[]>(Array(6).fill(null));

  const onKeyDown = (e: KeyboardEvent) => {
    // If user presses "Enter"
    if (e.key === "Enter") {
      if (currentGuess.length < 5) return;

      // Check if currentGuess is correct
      if (currentGuess === answer) {
        alert("Correct Answer!");
        // TODO: Game End Logic
        return;
      }

      // If currentGuess is not correct
      // Updating Guesses Array
      setGuesses((guesses) => {
        const newGuesses = Array(6).fill(null);
        guesses.map((guess, idx) => {
          if (idx === turnNumber) {
            newGuesses[idx] = currentGuess;
          } else {
            newGuesses[idx] = guess;
          }
        });
        return newGuesses;
      });

      // Reset Current Guess
      setCurrentGuess("");

      // Update turnNumber
      setTurnNumber((turnNumber) => turnNumber + 1);
    }

    if (e.key === "Backspace") {
      setCurrentGuess((currentGuess) => currentGuess.slice(0, -2));
    }

    // For all other keyboard inputs
    // TODO: only accept keyboard inputs
    setCurrentGuess((currentGuess) => {
      if (currentGuess.length < 5) {
        return currentGuess + e.key;
      }
      return currentGuess;
    });
  };

  useEffect(() => {
    const fetchWords = async () => {
      const response = await fetch(
        "https://raw.githubusercontent.com/chidiwilliams/wordle/refs/heads/main/src/data/words.json"
      );
      const words = await response.json();
      // TODO: randomize chosen
      setAnswer(words[0]);
    };

    fetchWords();
  }, []);

  useEffect(() => {
    document.addEventListener("keydown", onKeyDown);

    return () => {
      document.removeEventListener("keydown", onKeyDown);
    };
  }, []);

  useEffect(() => {
    if (turnNumber === 7) alert("Game Over");
    // TODO: Game End Logic
  }, [turnNumber]);

  return (
    <div className="app">
      {guesses.map((guess, idx) => {
        if (idx === turnNumber) return <Line key={idx} word={currentGuess} />;
        else {
          if (guess === null) guess = "";

          return <Line key={idx} word={guess} />;
        }
      })}
      <br />
    </div>
  );
}
